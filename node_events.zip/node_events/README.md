# Events Project using nodejs/MongoDB

This project to show the steps in my youtube course :

* [Node.js-MongoDB](https://www.youtube.com/playlist?list=PLXgJ7cArk9uR_xxd3iZIwTg0mKUDYsxoi) 


### Installing

Once you have cloned or downloaded this repo you need to make sure you have Mongo DB installed then

run the following command to bring all npm packages required for this project

```
npm install 
```